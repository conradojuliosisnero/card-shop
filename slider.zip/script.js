// Se inicializa un nuevo carrusel de Swiper para la clase '.mySwiper-1'.
var swiper1 = new Swiper(".mySwiper-1", {
    slidesPerView: 1, // Número de slides visibles a la vez.
    spaceBetween: 30, // Espacio entre slides en px.
    loop: true, // Habilita el bucle, los slides se repiten en un ciclo continuo.
    pagination: { // Configuración de la paginación.
        el: ".swiper-pagination", // Clase de los elementos de paginación.
        clickable: true, // Los puntos de paginación son clickeables.
    },
    navigation: { // Configuración de la navegación.
        nextEl: ".swiper-button-next", // Clase del botón para ir al siguiente slide.
        prevEl: ".swiper-button-prev", // Clase del botón para ir al slide anterior.
    }
});

// Se inicializa un segundo carrusel de Swiper para la clase '.mySwiper-2'.
var swiper = new Swiper(".mySwiper-2",{
    slidesPerView:3,
    spaceBetween: 20,
    loop:false,
    navigation:{
        nextEl:".swiper-button-next",
        prevEl:".swiper-button-prev",
    },
    breakpoints : {
        0: {
            slidesPerView:1,
        },
        520:{
            slidesPerView:2,
        },
        950:{
            slidesPerView:3,
        }
    }
});

// Se seleccionan todos los elementos con la clase '.tabInput'.
let tabInputs = document.querySelectorAll(".tabInput");

// Para cada uno de estos elementos...
tabInputs.forEach(function(input){
    // Se añade un 'event listener' para el evento 'change'.
    input.addEventListener('change', function(){
        // Cuando se dispara el evento 'change'...
        let id = input.ariaValueMax;
        // Se selecciona el carrusel de Swiper correspondiente.
        let thisSwiper = document.getElementById('swiper' + id);
        // Y se actualiza el carrusel de Swiper.
        thisSwiper.swiper.update();
    })
});